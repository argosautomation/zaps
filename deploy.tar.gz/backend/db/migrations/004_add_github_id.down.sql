ALTER TABLE users DROP COLUMN github_id;
