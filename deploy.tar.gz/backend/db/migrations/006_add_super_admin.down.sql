ALTER TABLE users DROP COLUMN is_super_admin;
