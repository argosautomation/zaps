'use client';

import LogExplorer from '@/components/dashboard/LogExplorer';

export default function LogsPage() {
    return (
        <div>
            <LogExplorer />
        </div>
    );
}
